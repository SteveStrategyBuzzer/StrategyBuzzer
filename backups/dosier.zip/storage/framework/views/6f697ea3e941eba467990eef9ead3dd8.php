<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>BuzzSound</title>
</head>
<body>
    <h1>Bienvenue sur BuzzSound 🎮</h1>
    <p>Le jeu est prêt à être lancé !</p>
</body>
</html><?php /**PATH C:\dev\StrategyBuzzer\resources\views/buzzsound.blade.php ENDPATH**/ ?>