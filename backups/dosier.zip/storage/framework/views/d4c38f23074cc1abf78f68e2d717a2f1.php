<?php $__env->startSection('content'); ?>
<div class="card" style="text-align: center;">
    <h2>🏁 Résultats de la partie</h2>

    <div id="podium" style="display: flex; justify-content: center; align-items: end; gap: 20px; margin: 40px 0;">
        <div class="player podium-2">🥈<br>Joueur 2<br><strong>80 pts</strong></div>
        <div class="player podium-1">🥇<br>Joueur 1<br><strong>100 pts</strong></div>
        <div class="player podium-3">🥉<br>Joueur 3<br><strong>70 pts</strong></div>
    </div>

    <p>Ton score : <strong id="score">85</strong> points</p>
    <p>Taux de bonnes réponses : <strong id="accuracy">85%</strong></p>
    <p>Rang final : <strong id="rank">4e place</strong></p>

    <p><a href="/start">🔁 Rejouer</a> | <a href="/">🏠 Retour au menu</a></p>
</div>

<script src="/js/results.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\StrategyBuzzer\resources\views/results.blade.php ENDPATH**/ ?>