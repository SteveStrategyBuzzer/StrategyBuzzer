<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Bienvenue dans BuzzSound!</h2>
    <p>Choisissez une option pour commencer :</p>
    <ul>
        <li><a href="/buzzsound">🎮 Jouer</a></li>
        <li><a href="/boutique">🛒 Boutique</a></li>
        <li><a href="/profil">🧑 Profil</a></li>
        <li><a href="/parametres">⚙️ Paramètres</a></li>
        <li><a href="/invitations">✉️ Invitations</a></li>
        <li><a href="/reglements">📜 Règlements</a></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\StrategyBuzzer\resources\views/menu.blade.php ENDPATH**/ ?>