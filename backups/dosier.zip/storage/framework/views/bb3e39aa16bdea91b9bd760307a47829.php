

<?php $__env->startSection('title', 'Buzzer'); ?>

<?php $__env->startSection('content'); ?>
    <div class="buzzer-screen">
        <h1>Appuie sur le BUZZ !</h1>
        <button class="buzz-button">BUZZ</button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\StrategyBuzzer\resources\views/buzzer.blade.php ENDPATH**/ ?>