export default {
  apiKey: "AIzaSyAB5-A0NsX9I9eFX76ZBYQQG_bqWp_dHw",
  authDomain: "strategybuzzergame.firebaseapp.com",
  projectId: "strategybuzzergame",
  storageBucket: "strategybuzzergame.appspot.com",
  messagingSenderId: "68047817391",
  appId: "1:68047817391:web:ba6b3bc148ef187bfeae9a"
};
