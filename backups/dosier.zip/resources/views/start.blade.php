@extends('layout')

@section('content')
<div class="card">
    <h2>Options de Jeu</h2>
    <p>Choisissez un mode :</p>
    <ul>
        <li><a href="/solo">🧠 Solo</a></li>
        <li><a href="/duo">👥 Duo</a></li>
        <li><a href="/maitre">🎓 Maître du Jeu</a></li>
        <li><a href="/ligue">🏆 Ligue</a></li>
    </ul>
    <p><a href="/">⬅️ Retour à l’accueil</a></p>
</div>
@endsection
