@extends('layouts.app')

@section('title', 'Paramètres')

@section('content')
    <div class="settings-screen">
        <h1>Réglages du jeu</h1>
        <form>
            <label>Volume:</label>
            <input type="range" min="0" max="100" value="50">
            <label>Langue:</label>
            <select>
                <option>Français</option>
                <option>English</option>
            </select>
        </form>
    </div>
@endsection
