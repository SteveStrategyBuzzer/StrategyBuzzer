@extends('layouts.app')

@section('title', 'Jeu en cours')

@section('content')
    <div class="game-screen">
        <h1>Le jeu commence !</h1>
        <p>Affichage de la question en cours...</p>
    </div>
@endsection

