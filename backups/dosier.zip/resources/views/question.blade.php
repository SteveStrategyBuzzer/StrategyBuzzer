@extends('layouts.app')

@section('title', 'Question')

@section('content')
    <div class="question-screen">
        <h1>Question ici</h1>
        <p>Choisis la bonne réponse :</p>
        <ul>
            <li>Réponse A</li>
            <li>Réponse B</li>
            <li>Réponse C</li>
            <li>Réponse D</li>
        </ul>
    </div>
@endsection
