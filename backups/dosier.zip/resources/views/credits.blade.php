@extends('layouts.app')

@section('title', 'Crédits')

@section('content')
    <div class="credits-screen">
        <h1>Merci d’avoir joué à BuzzSound</h1>
        <p>Développé avec❤️ par Steve & OpenAI</p>
        <p>Design, code et concept par une équipe passionnée</p>
    </div>
@endsection
