@extends('layouts.app')

@section('title', 'Sélection des Joueurs')

@section('content')
    <div class="player-select-screen">
        <h1>Choisis les joueurs</h1>
        <form>
            <label>Joueur 1</label>
            <input type="text" placeholder="Nom du joueur 1">
            <label>Joueur 2</label>
            <input type="text" placeholder="Nom du joueur 2">
            <button type="submit">Commencer</button>
        </form>
    </div>
@endsection

