@extends('layouts.app')

@section('title', 'BuzzSound')

@section('content')
    <div class="buzzsound-screen">
        <h1>Bienvenue sur BuzzSound 🎮</h1>
        <p>Le jeu est prêt à être lancé !</p>
    </div>
@endsection
