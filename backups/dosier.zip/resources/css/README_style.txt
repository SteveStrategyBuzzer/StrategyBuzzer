README - STYLES VISUELS
------------------------
Ce dossier contient les fichiers CSS responsables des styles visuels des différentes ambiances du jeu StrategyBuzzer :

- theme_fun.css : pour l'ambiance Fun
- theme_party.css : pour l'ambiance Party
- theme_intello.css : pour l'ambiance Intello
- theme_punchy.css : pour l'ambiance Punchy
- buzz-style.css : styles spéciaux pour le bouton de buzz

Chaque fichier doit être chargé dynamiquement en fonction de l'ambiance sélectionnée.
