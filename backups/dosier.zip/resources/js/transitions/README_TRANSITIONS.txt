README - TRANSITIONS

Fichier: transitions.js
Utilisation : Gère les transitions visuelles entre les écrans du jeu BuzzSound (maintenant StrategyBuzzer).

Contenu : Fonction fadeTransition pour effet fondu.
Destination : C:\dev\StrategyBuzzer\transitions\