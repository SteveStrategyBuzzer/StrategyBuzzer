README - VISUAL
----------------------
Ce dossier contient les éléments visuels du jeu BuzzSound / StrategyBuzzer :

- Avatars (scientifique, mathématicien, etc.)
- Arrière-plans thématiques (Fun, Intello, Party, Punchy)
- Feuilles de style CSS associées aux ambiances

À placer dans :
C:\dev\StrategyBuzzer\resources\js\visual\
