BuzzSound - PAGES
----------------------
Ce dossier contient les pages React principales du jeu BuzzSound.
À intégrer dans : C:\dev\StrategyBuzzer\pages

Contenu :
- PageAccueil.jsx : page d’accueil interactive du jeu
- README.txt : ce fichier explicatif

Instructions :
1. Copier ce dossier dans le projet Laravel StrategyBuzzer.
2. Placer son contenu dans un dossier nommé "pages".
3. Vérifier les imports vers les composants du jeu.