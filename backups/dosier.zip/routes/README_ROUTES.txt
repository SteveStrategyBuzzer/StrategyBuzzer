📁 ROUTES

Ce dossier contient les fichiers de routes Laravel.

- web.php : Définit les routes web accessibles via le navigateur.
- api.php : Définit les routes d'API (utilisées pour les appels AJAX ou externes).

À placer dans :
C:\dev\StrategyBuzzer\routes\
