📁 Dossier : STRUCTURE

Ce dossier contient la carte de structure du jeu BuzzTime renommé StrategyBuzzer.
Le fichier JSON définit l’ordre des pages, les liens entre elles et la logique d’enchaînement des vues.

Fichiers inclus :
- buzz_structure_map.json : carte des écrans du jeu
- README_STRUCTURE.txt : ce fichier d'instructions

À faire de ton côté :
1. Place le fichier JSON dans : C:\dev\StrategyBuzzer\structure
2. Vérifie que les transitions et pages correspondent bien à cette carte

Structure vérifiée au : 26 mai 2025 – 01h05 (Heure du Québec)
