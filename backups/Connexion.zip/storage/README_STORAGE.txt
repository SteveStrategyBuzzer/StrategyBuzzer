Ce dossier est utilisé pour stocker des fichiers temporaires, des exports, des rapports ou des journaux d’activité générés dynamiquement par le jeu BuzzTime (ex: scores, logs, avatars importés).

Ce dossier est ignoré par Git (.gitignore) car il contient des fichiers volatiles et non versionnés.
