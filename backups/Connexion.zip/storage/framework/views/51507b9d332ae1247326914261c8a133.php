<h1>Sélection des joueurs</h1>
<?php /**PATH C:\dev\StrategyBuzzer\resources\views/player-select.blade.php ENDPATH**/ ?>