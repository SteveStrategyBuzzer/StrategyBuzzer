

<?php $__env->startSection('title', 'Crédits'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Crédits</h1>
    <p>Développé avec amour par Steve et ChatGPT 🤝</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\StrategyBuzzer\resources\views/credits.blade.php ENDPATH**/ ?>