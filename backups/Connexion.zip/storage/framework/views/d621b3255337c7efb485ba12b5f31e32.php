<h1>Jeu en cours</h1>
<?php /**PATH C:\dev\StrategyBuzzer\resources\views/game.blade.php ENDPATH**/ ?>