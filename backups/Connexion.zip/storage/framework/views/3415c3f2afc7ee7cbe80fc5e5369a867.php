<h1>Paramètres du jeu</h1>
<?php /**PATH C:\dev\StrategyBuzzer\resources\views/settings.blade.php ENDPATH**/ ?>