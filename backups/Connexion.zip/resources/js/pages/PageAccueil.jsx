import React from 'react';

export default function PageAccueil() {
  return <div>Bienvenue sur BuzzSound !</div>;
}