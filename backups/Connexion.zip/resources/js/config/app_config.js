// Fichier de configuration principal
const config = {};