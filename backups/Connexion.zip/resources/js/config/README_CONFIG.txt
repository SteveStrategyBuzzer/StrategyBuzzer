📘 Ce dossier contient les fichiers de configuration pour StrategyBuzzer.
À placer dans : C:\dev\StrategyBuzzer\config\
