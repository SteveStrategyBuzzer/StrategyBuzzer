
README - IA (quizbot.js)

Ce fichier contient l’IA QuizBot utilisée pour générer dynamiquement les questions dans BuzzTime.

Fichier :
- quizbot.js : Fonction de génération de question simulée

À placer dans :
C:\dev\StrategyBuzzer\ia\
