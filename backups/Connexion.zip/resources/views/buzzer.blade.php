@extends('layouts.app')

@section('title', 'Buzzer')

@section('content')
    <div class="buzzer-screen">
        <h1>Appuie sur le BUZZ !</h1>
        <button class="buzz-button">BUZZ</button>
    </div>
@endsection

