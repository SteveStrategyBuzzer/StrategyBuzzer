<?php

use Illuminate\Support\Facades\Route;
use Kreait\Firebase\Factory;

Route::get('/', function () {
    return view('menu');
});

Route::get('/buzzsound', function () {
    return view('buzzsound');
});

Route::get('/buzzer', function () {
    return view('buzzer');
});

Route::get('/question', function () {
    return view('question');
});

Route::get('/start', function () {
    return view('start');
});

Route::get('/settings', function () {
    return view('settings');
});

Route::get('/player-select', function () {
    return view('player-select');
});

Route::get('/game', function () {
    return view('game');
});

Route::get('/results', function () {
    return view('results');
});

Route::get('/credits', function () {
    return view('credits');
});

// TEST FIREBASE
Route::get('/test-firestore', function () {
    $factory = (new Factory)->withServiceAccount(config('firebase.credentials'));

    try {
        $firestore = $factory->createFirestore();
        $database = $firestore->database();

        $docRef = $database->collection('tests')->document('test-connexion');
        $docRef->set([
            'message' => 'Connexion Firebase OK',
            'timestamp' => now()->toDateTimeString(),
        ]);

        return response('✅ Connexion réussie et document écrit dans Firestore.', 200);
    } catch (\Throwable $e) {
        return response('❌ Erreur Firebase : ' . $e->getMessage(), 500);
    }
});
